package com.example.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;

	//@Controller+@Responsebody=@RestController
	@RestController
	@RequestMapping("/products")
	public class EmployeeController {

		@Autowired
		EmployeeService service;
		
		@PostMapping("/addproduct")
		public  String addEmployee(@RequestBody Employee product) {
			return service.addEmployees(product);
		}
		
		@PutMapping("/updateproduct")
		public  String updateEmployees(@RequestBody Employee product) {
			return service.UpdateEmployee(product);
		}
		
		@DeleteMapping("/deleteproduct")
		public  String deleteEmployees(@PathVariable("id") int productId) {
			return service.deleteEmployee(productId);
		}
		
		@GetMapping("getproduct/{id}")
		public  Employee getEmployeesById(@PathVariable("id") int productId) {
			return  service.getEmployeeByID(productId);
		}
		
		@GetMapping("getallproducts")
		public  List<Employee> getAllEmployees() {
			return  service.getAllEmployees();
		}
		
		@GetMapping("getproductsbetween/{iprice}/{fprice}")
		public List<Employee> getAllEmployeesBetweenPrices(@PathVariable("iprice")int initialPrice,@PathVariable("fprice")int finalprice)
		{
			return service.getAllEmployeesBetweenPrices(initialPrice, finalprice);
		}

		
		
		@GetMapping("getallproductsbycategory/{category}")
		public List<Employee> getAllEmployeeByCategory(@PathVariable("category")String productCategory)
		{
			return service.getAllEmployeesByCategory(productCategory);
		}
		

	}


