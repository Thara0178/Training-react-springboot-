package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.EmployeeDAO;
import com.example.demo.entity.Employee;
import jakarta.transaction.Transactional;
	 
	@Service
	@Transactional
	public class EmployeeServiceImpl implements EmployeeService {
		
		@Autowired
		EmployeeDAO dao;
	 
		public EmployeeServiceImpl() {
			// TODO Auto-generated constructor stub
		}
	 
		@Override
		public String addEmployees(Employee employee) {
			// TODO Auto-generated method stub
			return dao.addEmployees(employee);
		}
	 
		@Override
		public String UpdateEmployee(Employee employee) {
			// TODO Auto-generated method stub
			return dao.updateEmployees(employee);
		}
	 
		@Override
		public String deleteEmployee(int employeeId) {
			// TODO Auto-generated method stub
			return dao.deleteEmployees(employeeId);
		}
	 
		@Override
		public Employee getEmployeeByID(int employeeId) {
			// TODO Auto-generated method stub
			return dao.getEmployeesById(employeeId);
		}
	 
		@Override
		public List<Employee> getAllEmployees() {
			// TODO Auto-generated method stub
			return dao.getAllEmployees();
		}
	 
		@Override
		public List<Employee> getAllEmployeesBetweenPrices(int intialPrice, int finalPrice) {
			// TODO Auto-generated method stub
			return dao.getAllEmployeesBetweenPrices(intialPrice, finalPrice);
		}
	 
		@Override
		public List<Employee> getAllEmployeesByCategory(String employeeCategory) {
			// TODO Auto-generated method stub
			return dao.getAllEmployeesByCategory(employeeCategory);
		}
	 
	}
	 

