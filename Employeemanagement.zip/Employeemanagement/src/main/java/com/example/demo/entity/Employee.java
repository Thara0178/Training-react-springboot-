package com.example.demo.entity;

import jakarta.persistence.*;
import jakarta.persistence.Table;

@Entity
@Table(name="employees_info")

public class Employee {
	@Id
	@GeneratedValue
	
	@Column(name="pid")
	private int employeeId;
	
	private String employeeName;
	
	@Column(name= "price")
	private int employeePrice;
	private String employeeCategory;
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getEmployeePrice() {
		return employeePrice;
	}
	public void setEmployeePrice(int employeePrice) {
		this.employeePrice = employeePrice;
	}
	public String getEmployeeCategory() {
		return employeeCategory;
	}
	public void setEmployeeCategory(String employeeCategory) {
		this.employeeCategory = employeeCategory;
	}
	
}
