package com.example.demo.dao;
import org.springframework.stereotype.*;
import java.util.List;
import com.example.demo.entity.Employee;
import jakarta.persistence.*;

@Repository
public  class EmployeeDaoImpl implements EmployeeDAO {
	@PersistenceContext
	EntityManager entityManager;
	

	@Override
	public String addEmployees(Employee employee) {
		entityManager.persist(employee);
		return "Employee Saved Successfully";
	}

	@Override
	public String updateEmployees(Employee employee) {
		// TODO Auto-generated method stub
		
		entityManager.merge(employee);
		return "Employee Updated Successfully";
		
	}

	@Override
	public String deleteEmployees(int employeeId) {
		// TODO Auto-generated method stub
		entityManager.remove(getEmployeesById(employeeId));
		return "Employee Deleted Successfully";
			}


	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		
		TypedQuery<Employee> employees = entityManager
				.createQuery("select p from employee p",Employee.class);
		return employees.getResultList();
	}//select* from produt_info

	
	
	

	@Override
	public List<Employee> getAllEmployeesByCategory(String employeeCategory) {
		// TODO Auto-generated method stub
		
		TypedQuery<Employee> employees = entityManager
				.createQuery("select p from employee p where p.employeeCategory =?",Employee.class);
					employees.setParameter(1, employeeCategory);
		return employees.getResultList();
		
	}

	@Override
	public Employee getEmployeesById(int employeeId) {
		// TODO Auto-generated method stub
		entityManager.find(Employee.class,employeeId);
		return null;
	}

	@Override
	public List<Employee> getAllEmployeesBetweenPrices(int intialPrice, int finalPrice) {
		// TODO Auto-generated method stub
			TypedQuery<Employee> employees = entityManager
					.createQuery("select p from employee p where p.employeePrice between ?1 and ?2",Employee.class);
						employees.setParameter(1, intialPrice);
						employees.setParameter(2,finalPrice);
			return employees.getResultList();
			}//select*from employee_info where price between inital and final
		

	@Override
	public List<Employee> getAllEmployeesBetweenPrices(int intialPrice) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee getEmployeesById1(int employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}
	

	
