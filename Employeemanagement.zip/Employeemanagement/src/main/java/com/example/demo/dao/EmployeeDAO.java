package com.example.demo.dao;

import java.util.List;

import com.example.demo.entity.Employee;

public interface EmployeeDAO {
	
	abstract  String addEmployees(Employee employee);
	abstract  String updateEmployees(Employee employee);
	abstract  String deleteEmployees(int employeeId);
	abstract  Employee getEmployeesById(int employeeId);
	abstract  List<Employee> getAllEmployees();
	abstract  List<Employee> getAllEmployeesBetweenPrices(int intialPrice,int finalPrice);
	abstract  List<Employee> getAllEmployeesByCategory(String employeeCategory);
	abstract Employee getEmployeesById1(int employeeId);
	List<Employee> getAllEmployeesBetweenPrices(int intialPrice);
	
}
