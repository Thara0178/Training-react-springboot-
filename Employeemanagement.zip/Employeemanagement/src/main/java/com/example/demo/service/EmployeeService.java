package com.example.demo.service;
 
import java.util.List;
 
import com.example.demo.entity.Employee;
 
public interface EmployeeService {
 
	 abstract String addEmployees(Employee employee);
	 abstract String UpdateEmployee(Employee employee);
	 abstract String deleteEmployee(int employeeId);
	 abstract Employee getEmployeeByID(int employeeId);
	 abstract List<Employee> getAllEmployees();
	 abstract List<Employee> getAllEmployeesBetweenPrices(int intialPrice,int finalPrice);
	 abstract List<Employee> getAllEmployeesByCategory(String employeeCategory);
}

