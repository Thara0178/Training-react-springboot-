package com.example.demo.dao;
import org.springframework.stereotype.*;
import java.util.List;
import com.example.demo.entity.Product;
import jakarta.persistence.*;


@Repository
public class ProductDaoImpl implements ProductDAO {
	@PersistenceContext
	EntityManager entityManager;
	

	@Override
	public String addProducts(Product product) {
		entityManager.persist(product);
		return "Product Saved Successfully";
	}

	@Override
	public String updateProducts(Product product) {
		// TODO Auto-generated method stub
		
		entityManager.merge(product);
		return "Product Updated Successfully";
		
	}

	@Override
	public String deleteProducts(int productId) {
		// TODO Auto-generated method stub
		entityManager.remove(getProductsById(productId));
		return "Product Deleted Successfully";
			}

	@Override
	public Product getProductsById(int productId) {
		// TODO Auto-generated method stub
		
		entityManager.find(Product.class,productId);
		return null;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		
		TypedQuery<Product> products = entityManager
				.createQuery("select p from product p",Product.class);
		return products.getResultList();
	}//select* from produt_info

	@Override
	public List<Product> getAllProductsBetweenPrices(int intialPrice, int finalPrice) {
		// TODO Auto-generated method stub
		
		TypedQuery<Product> products = entityManager
				.createQuery("select p from product p where p.productPrice between ?1 and ?2",Product.class);
					products.setParameter(1, intialPrice);
					products.setParameter(2,finalPrice);
		return products.getResultList();
		
	}//select*from product_info where price between inital and final

	@Override
	public List<Product> getAllProductsByCategory(String productCategory) {
		// TODO Auto-generated method stub
		
		TypedQuery<Product> products = entityManager
				.createQuery("select p from product p where p.productCategory =?",Product.class);
					products.setParameter(1, productCategory);
		return products.getResultList();
	}
	

}
