package com.example.demo.service;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.example.demo.dao.ProductDAO;
import com.example.demo.entity.Product;
 
import jakarta.transaction.Transactional;
 
@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductDAO dao;
 
	public ProductServiceImpl() {
		// TODO Auto-generated constructor stub
	}
 
	@Override
	public String addProducts(Product product) {
		// TODO Auto-generated method stub
		return dao.addProducts(product);
	}
 
	@Override
	public String UpdateProduct(Product product) {
		// TODO Auto-generated method stub
		return dao.updateProducts(product);
	}
 
	@Override
	public String deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return dao.deleteProducts(productId);
	}
 
	@Override
	public Product getProductByID(int productId) {
		// TODO Auto-generated method stub
		return dao.getProductsById(productId);
	}
 
	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return dao.getAllProducts();
	}
 
	@Override
	public List<Product> getAllProductsBetweenPrices(int intialPrice, int finalPrice) {
		// TODO Auto-generated method stub
		return dao.getAllProductsBetweenPrices(intialPrice, finalPrice);
	}
 
	@Override
	public List<Product> getAllProductsByCategory(String productCategory) {
		// TODO Auto-generated method stub
		return dao.getAllProductsByCategory(productCategory);
	}
 
}