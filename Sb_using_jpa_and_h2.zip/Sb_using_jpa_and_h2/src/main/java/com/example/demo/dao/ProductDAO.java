package com.example.demo.dao;

import java.util.List;

import com.example.demo.entity.Product;

public interface ProductDAO {
	
	abstract  String addProducts(Product product);
	abstract  String updateProducts(Product product);
	abstract  String deleteProducts(int productId);
	abstract  Product getProductsById(int productId);
	abstract  List<Product> getAllProducts();
	abstract  List<Product> getAllProductsBetweenPrices(int intialPrice,int finalPrice);
	abstract  List<Product> getAllProductsByCategory(String productCategory);
	
}
